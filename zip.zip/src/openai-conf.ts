export const YOUR_API_KEY = "YOUR_API_KEY";
export const MAX_TOKENS = 50; // 设置生成的回复长度
export const TEMPERATURE = 0.6; // 设置回复的创造性程度，值越大越创造性，但也会更加不确定
